public class parametrosInvalidosException extends Exception {
    public parametrosInvalidosException() {
        super("O segundo parâmetro deve ser maior que o primeiro.");
    }
}